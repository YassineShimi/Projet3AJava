package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import models.Reclamation;
import models.Reponse;
import services.ReclamationServices;
import services.ReponseServices;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;

public class AjouterReponsee {
    @FXML
    private TextField dp;

    private Reclamation reclamation;
    private Reponse r;
    private ListReclamation listReclamationController;

    private ReponseServices rs = new ReponseServices();

    public void initData(Reclamation reclamation, ListReclamation listReclamationController) {
        this.reclamation = reclamation;
        this.listReclamationController = listReclamationController;

    }

    @FXML

    public void ajouterReponse(ActionEvent actionEvent) {
        try {
            Reponse reponse= new Reponse ();
            reponse.setDescription(dp.getText());
            int id=rs.ajouterReturnsID(reponse);
            reclamation.setReponse_id(id);
            reclamation.setEtat(1);
            ReclamationServices rs=new ReclamationServices();
            rs.modifierReponse(reclamation);

          //  validerReponse();

            if (listReclamationController != null) {
                listReclamationController.updateTableView();
            } else {
                System.err.println("Erreur : listReclamationController est null.");

            }


            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.close();
        } catch (SQLException e) {

        }
    }


    public void validerReponse() {

        try {
            ArrayList<Reponse> reponses=new ArrayList<Reponse>(rs.getAllReponsees());
            reclamation.setEtat(1);
            reclamation.setReponse_id(reponses.get(reponses.size()-1).getId());
            ReclamationServices rs=new ReclamationServices();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    private void showAlert(Alert.AlertType alertType, String title, String headerText, String contentText) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(contentText);
        alert.showAndWait();
    }
    public void openReplyWindow(Reclamation reclamation) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/AjouterReponsee.fxml"));
            Parent root = loader.load();

            AjouterReponsee controller = loader.getController();

            // Initialiser listReclamationController en récupérant une référence au contrôleur ListReclamation
            FXMLLoader listLoader = new FXMLLoader(getClass().getResource("/listReclamation.fxml"));
            Parent listRoot = listLoader.load();
            ListReclamation listController = listLoader.getController();

            controller.initData(reclamation, listController); // Passer une référence à ListReclamation pour mettre à jour l'état et la réponse

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.showAndWait(); // Attendre la fermeture de la fenêtre de réponse


            listController.updateTableView();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // ...
}
