package controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;
import models.Reclamation;
import models.Reponse;
import services.ReclamationServices;
import services.ReponseServices;

import java.io.IOException;
import java.sql.SQLException;

public class ReclamationItemController {

    public Label etat;
    public HBox editReclamation;
    public HBox DisplayReply;
    public HBox DeleteReclamation;
    @FXML
    private Text comment;

    @FXML
    private Label title;

    ReclamationServices rs=new ReclamationServices();
    private void showAlert(Alert.AlertType alertType, String title, String headerText, String contentText) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(contentText);
        alert.showAndWait();
    }
    private ReponseServices reponseCrud = new ReponseServices();
    @FXML
    Label type;
    public void setReclamationsData(Reclamation reclamation) {
        title.setText(reclamation.getNom());
        comment.setText(reclamation.getDescription());
        type.setText(reclamation.getType());
          if(reclamation.getReponse_id()!=0)
            etat.setText("Traitée");
        else {
            System.out.println("non traitée" + reclamation.getEtat());
            etat.setText("Non traitée");
            etat.setStyle("-fx-text-fill: red;");
            etat.applyCss();
            this.DisplayReply.setVisible(false);

        }
        this.DisplayReply.setOnMouseClicked(event -> {
            System.out.println("ID du réclamation à voir réponse : " + reclamation.getId());
            showAlert(Alert.AlertType.INFORMATION, "Réponse de réclamation", "Réponse", reclamation.getReponse().getDescription());

        });
        this.DeleteReclamation.setOnMouseClicked(event -> {
            System.out.println("ID du réclamation à voir réponse : " + reclamation.getId());
            if (reclamation.getReponse_id()<1){
                try {
                    rs.supprimer(reclamation);
                    showAlert(Alert.AlertType.INFORMATION, "Succéées", "Réponse supprimé","La réclamation à été supprimer avec succées");
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
           else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Réponse","La réclamation à été déja traitée");
            }
        });

        editReclamation.setId(String.valueOf(reclamation.getId()));
        editReclamation.setOnMouseClicked(event -> {
            System.out.println("ID du reclamation à modifier : " + reclamation.getId());
            System.out.println(reclamation.getEtat());
            if(reclamation.getEtat()==0) {
                ModifierReclamation.reclamation = reclamation;
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/modifierReclamation.fxml"));
                Parent root = null;
                try {
                    root = loader.load();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

                ModifierReclamation controller = loader.getController();
                controller.initData(reclamation);
                Stage stage = new Stage();
                stage.setScene(new Scene(root));

                // Attendez la fermeture de la fenêtre de modification


                stage.show();
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Réponse","La réclamation à été déja traitée");
            }
        });

    }


}
