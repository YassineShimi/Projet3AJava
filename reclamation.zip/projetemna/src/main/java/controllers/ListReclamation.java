package controllers;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import models.Reclamation;
import services.ReclamationServices;

import java.io.IOException;
import java.sql.SQLException;


import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import models.Reclamation;
import services.ReclamationServices;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;


public class ListReclamation {
    @FXML
    private TableView<Reclamation> tableViewAvis;
    private Button buttonafficherstat;
    private ReclamationServices reclamationServices;

    public ListReclamation() {
        this.reclamationServices = new ReclamationServices();
    }
   public ListReclamation listReclamationController ;
    @FXML
    void initialize() {

        try {
            // Créer les colonnes pour le TableView
            TableColumn<Reclamation, String> descriptionColumn = new TableColumn<>("Description");
            descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));


            TableColumn<Reclamation, Integer> nomColumn = new TableColumn<>("nom de l utilisateur");
            nomColumn.setCellValueFactory(new PropertyValueFactory<>("nom")); // Co  typeColumn.setCellValueFactory(new PropertyValueFactory<>("type")); // Correction ici
            TableColumn<Reclamation, String> typeColumn = new TableColumn<>("Type");
            typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
            TableColumn<Reclamation, String> responseColumn = new TableColumn<>("Response");
            responseColumn.setCellValueFactory(cellData -> {
                Reclamation reclamation = cellData.getValue();
                String description = (reclamation.getReponse() != null) ? reclamation.getReponse().getDescription() : "";
                return new SimpleStringProperty(description);
            });
            // Ajouter les colonnes au TableView
            tableViewAvis.getColumns().addAll(descriptionColumn, nomColumn, typeColumn,responseColumn);

            // Ajouter la colonne "Supprimer"
            TableColumn<Reclamation, Reclamation> deleteColumn = new TableColumn<>("Supprimer");
            deleteColumn.setCellValueFactory(param -> new ReadOnlyObjectWrapper<>(param.getValue())); // Utiliser ReadOnlyObjectWrapper
            deleteColumn.setCellFactory(param -> new TableCell<>() {
                private final Button deleteButton = new Button("Supprimer");

                {
                    deleteButton.setOnAction(event -> {
                        Reclamation reclamation = getTableView().getItems().get(getIndex());
                        try {
                            reclamationServices.supprimer(reclamation); // Supprimer la réclamation de la base de données
                            getTableView().getItems().remove(reclamation); // Supprimer la réclamation de la TableView
                        } catch (SQLException e) {
                            showAlert(Alert.AlertType.ERROR, "Erreur", "Erreur lors de la suppression de la réclamation", e.getMessage());
                        }
                    });
                }

                @Override
                protected void updateItem(Reclamation item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setGraphic(null);
                    } else {
                        setGraphic(deleteButton);
                    }
                }
            });

            tableViewAvis.getColumns().add(deleteColumn);

            // Ajouter la colonne "Modifier"
            TableColumn<Reclamation, Reclamation> modifyColumn = new TableColumn<>("Modifier");
            modifyColumn.setCellValueFactory(param -> new ReadOnlyObjectWrapper<>(param.getValue())); // Utiliser ReadOnlyObjectWrapper
            modifyColumn.setCellFactory(param -> new TableCell<>() {
                private final Button modifyButton = new Button("Modifier");

                {
                    modifyButton.setOnAction(event -> {
                        Reclamation reclamation = getTableView().getItems().get(getIndex());
                        try {
                            ModifierReclamation.reclamation=reclamation;
                            FXMLLoader loader = new FXMLLoader(getClass().getResource("/modifierReclamation.fxml"));
                            Parent root = loader.load();

                            ModifierReclamation controller = loader.getController();
                            controller.initData(reclamation);

                            Stage stage = new Stage();
                            stage.setScene(new Scene(root));

                            // Attendez la fermeture de la fenêtre de modification


                            stage.show();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    });
                }

                @Override
                protected void updateItem(Reclamation item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setGraphic(null);
                    } else {
                        setGraphic(modifyButton);
                    }
                }
            });


            tableViewAvis.getColumns().add(modifyColumn);

            // Récupérer la liste des réclamations depuis le service
            ObservableList<Reclamation> reclamations = FXCollections.observableArrayList(reclamationServices.afficher());
            System.out.println(reclamations);
            // Filtrer les réclamations pour exclure celles avec des champs vides
            ObservableList<Reclamation> filteredReclamations = FXCollections.observableArrayList();
            for (Reclamation reclamation : reclamations) {
                if (reclamation.getDescription() != null && !reclamation.getDescription().isEmpty() &&
                        reclamation.getNom() != null ) {
                    filteredReclamations.add(reclamation);
                }
            }

            // Ajouter les données filtrées à la TableView
            tableViewAvis.setItems(filteredReclamations);

            // Définir la largeur des colonnes en fonction du contenu
            descriptionColumn.prefWidthProperty().bind(tableViewAvis.widthProperty().multiply(0.4));
            nomColumn.prefWidthProperty().bind(tableViewAvis.widthProperty().multiply(0.3));

            // Ajuster automatiquement la taille du TableView
            tableViewAvis.autosize();

        } catch (SQLException e) {
            // Gestion de l'exception...
            showAlert(Alert.AlertType.ERROR, "Erreur", "Erreur lors du chargement des réclamations", e.getMessage());
        }
        // Ajouter la colonne "Répondre"
        TableColumn<Reclamation, Reclamation> replyColumn = new TableColumn<>("Répondre");
        replyColumn.setCellValueFactory(param -> new ReadOnlyObjectWrapper<>(param.getValue())); // Utiliser ReadOnlyObjectWrapper
        replyColumn.setCellFactory(param -> new TableCell<>() {
            private final Button replyButton = new Button("Répondre");

            {
                replyButton.setOnAction(event -> {
                    Reclamation reclamation = getTableView().getItems().get(getIndex());
                    openReplyWindow(reclamation);
                });
            }
            private void openReplyWindow(Reclamation reclamation) {
                System.out.println(reclamation);
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/AjouterReponsee.fxml"));
                    Parent root = loader.load();

                    AjouterReponsee controller = loader.getController();
                    controller.initData(reclamation, ListReclamation.this); // Passer une référence à ListReclamation pour mettre à jour l'état et la réponse

                    Stage stage = new Stage();
                    stage.setScene(new Scene(root));
                    stage.showAndWait(); // Attendre la fermeture de la fenêtre de réponse

                    // Mettre à jour la TableView après la fermeture de la fenêtre de réponse en utilisant la méthode de ListReclamation
                    this.updateTableView();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            private void updateTableView() {
            }


            @Override
            protected void updateItem(Reclamation item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null || item.getReponse() != null) {
                    setGraphic(null);
                } else {
                    setGraphic(replyButton);
                }
            }
        });

        tableViewAvis.getColumns().add(replyColumn);

    }

    private void showAlert(Alert.AlertType alertType, String title, String headerText, String contentText) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(contentText);
        alert.showAndWait();
    }

    public void retourPagePrecedente(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/accueil2.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();

        }
    }

    @FXML
    void buttonstat(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Stats.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();

        }

    }
    public void updateTableView() {
        // Mettre à jour la TableView avec les nouvelles données
        tableViewAvis.refresh();
    }
    @FXML

    public void handleafficherstat(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Stats.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    private void pdf(javafx.scene.input.MouseEvent event) throws SQLException {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Enregistrer le fichier PDF");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Fichiers PDF", "*.pdf"));
        File selectedFile = fileChooser.showSaveDialog(((Node) event.getSource()).getScene().getWindow());

        if (selectedFile != null) {
            List<Reclamation> reclamationsList = tableViewAvis.getItems();

            try {
                Document document = new Document();
                PdfWriter.getInstance(document, new FileOutputStream(selectedFile));
                document.open();

                Font titleFont = new Font(Font.FontFamily.TIMES_ROMAN, 32, Font.BOLD, BaseColor.DARK_GRAY);
                Paragraph title = new Paragraph("Liste des réclamations", titleFont);
                title.setAlignment(Element.ALIGN_CENTER);
                title.setSpacingAfter(20);
                document.add(title);

                PdfPTable table = new PdfPTable(4);
                table.setWidthPercentage(100);
                table.setSpacingBefore(10);

                String[] headers = {"DESCRIPTION", "NOM", "TYPE", "Réponse"};
                Font headerFont = new Font(Font.FontFamily.TIMES_ROMAN, 14, Font.BOLD, BaseColor.BLACK);
                for (String header : headers) {
                    PdfPCell cell = new PdfPCell(new Paragraph(header, headerFont));
                    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                    table.addCell(cell);
                }

                for (Reclamation reclamation : reclamationsList) {
                    table.addCell(reclamation.getDescription());
                    table.addCell(reclamation.getNom());
                    table.addCell(reclamation.getType());



                }

                document.add(table);
                document.close();

                System.out.println("Le fichier PDF a été généré avec succès.");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    @FXML

    private void sortHorsesByName() {
        try {
            // Récupérer la liste des chevaux depuis le service
            List<Reclamation> sortedreclam = reclamationServices.afficher()
                    .stream()
                    .sorted(Comparator.comparing(Reclamation::getNom)) // Tri par le nom
                    .collect(Collectors.toList());

            // Effacer la table et ajouter les chevaux triés
            tableViewAvis.getItems().clear();
            tableViewAvis.getItems().addAll(sortedreclam);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
