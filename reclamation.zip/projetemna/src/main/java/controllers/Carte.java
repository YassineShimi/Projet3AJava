package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import models.Reclamation;

public class Carte {
    @FXML
    private Label type;

    @FXML
    private Label description;

    public void setData(Reclamation reclamation) {
        type.setText("Type : " + reclamation.getType());
        description.setText("Description : " + reclamation.getDescription());
    }
}
