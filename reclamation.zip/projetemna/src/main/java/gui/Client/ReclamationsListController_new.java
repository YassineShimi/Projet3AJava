package gui.Client;

import models.*;
import services.*;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;

import services.ReclamationServices;
import javax.net.ssl.SSLContext;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.ResourceBundle;

public class ReclamationsListController_new implements Initializable {

    public HBox addReviewsModel;
  //  public HBox updateBtnContainer;
    public TextArea commentInput;
    public TextField titleInput;
    public ComboBox<String> TypeInput;
    public HBox updateBtnContainer;
    public HBox submitBtn;
    public HBox updateBtn;
    public HBox viewReplyModel;
    public TextArea replyInput;

    @FXML
        private GridPane commentsListContainer;

        @FXML
        private VBox content_area;
        @FXML
        private ImageView img;



       // private User user = null;



        @Override
        public void initialize(URL url, ResourceBundle rb) {

            this.viewReplyModel.setVisible(false);

            updateBtnContainer.setVisible(false);
            addReviewsModel.setVisible(false);
            TypeInput.getItems().addAll("Activité", "Logement", "Restaurant", "Transport");
            // recuperer user connecté
         //   user = new User();
       System.out.println("Setting reclamations");
            ReclamationServices ps = new ReclamationServices();

            List<Reclamation> reclamationList = null;
            try {
                reclamationList = ps.afficher();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

            // Set Reclamations List
            int ReclamationColumn = 0;
            int ReclamationRow = 1;
            try {
                for (int i = 0; i < reclamationList.size(); i++) {

                    FXMLLoader fxmlLoader = new FXMLLoader();
                    fxmlLoader.setLocation(getClass().getResource("/RecItem/ReclamationItem.fxml"));
                    VBox commentItem = fxmlLoader.load();
                    ReclamationItem ReclamationItemController = fxmlLoader.getController();
                    ReclamationItemController.setReviewData(reclamationList.get(i));

                    if (ReclamationColumn == 1) {
                        ReclamationColumn = 0;
                        ++ReclamationRow;
                    }
                    commentsListContainer.add(commentItem, ReclamationColumn++, ReclamationRow);
                    GridPane.setMargin(commentItem, new Insets(0, 10, 15, 10));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.println("Reclamations are ready");
        }


        @FXML
        void open_addReviewModel(MouseEvent event) throws SQLException {
            System.out.println("Opening modify/addview modal");
            HBox addReviewsModel = (HBox) ((Node) event.getSource()).getScene().lookup("#addReviewsModel");
            submitBtn.setVisible(true);
            submitBtn.setDisable(false);

            addReviewsModel.setVisible(true);
        }

    public void close_addReviewsModel(MouseEvent mouseEvent) {
        this.commentInput.setText("");
        this.titleInput.setText("");
        this.TypeInput.getSelectionModel().select(0);
        this.selectedImageFile=null;
        this.img.setImage(null);
        this.updateBtn.setVisible(false);
        this.submitBtn.setVisible(true);
        addReviewsModel.setVisible(false);

    }
    @FXML
    DatePicker dateAjout;
    public void add_new_comment(MouseEvent mouseEvent) throws IOException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException, SQLException {
        Reclamation reclamation = new Reclamation();

        if(TypeInput.getSelectionModel().getSelectedIndex()==-1)
        {
      //      utils.TrayNotificationAlert.notif("Reclamation", "Please select a type.",
        //            NotificationType.ERROR, AnimationType.POPUP, Duration.millis(2500));
            return;
        }
        if( titleInput.getText().isEmpty() || commentInput.getText().isEmpty()){
          //  utils.TrayNotificationAlert.notif("Reclamation", "Please fill all the fields.",
            //        NotificationType.ERROR, AnimationType.POPUP, Duration.millis(2500));
            return;
        }
        if(titleInput.getText().isEmpty() || commentInput.getText().isEmpty()){
            //utils.TrayNotificationAlert.notif("Reclamation", "Please fill all the fields.",
              //      NotificationType.ERROR, AnimationType.POPUP, Duration.millis(2500));
            return;
        }
        if(titleInput.getText().length() < 5){
            //utils.TrayNotificationAlert.notif("Reclamation", "Title must contain at least 5 characters.",
              //      NotificationType.ERROR, AnimationType.POPUP, Duration.millis(2500));
            return;
        }
        if (commentInput.getText().length() < 10) {
            //utils.TrayNotificationAlert.notif("Reclamation", "Description must contain at least 10 characters.",
              //      NotificationType.ERROR, AnimationType.POPUP, Duration.millis(2500));
            return;
        }
        if (commentInput.getText().length() > 255) {
            //utils.TrayNotificationAlert.notif("Reclamation", "Description must contain at most 255 characters.",
              //      NotificationType.ERROR, AnimationType.POPUP, Duration.millis(2500));
            return;
        }
        if (titleInput.getText().length() > 15) {
            //utils.TrayNotificationAlert.notif("Reclamation", "Title must contain at most 15 characters.",
              //      NotificationType.ERROR, AnimationType.POPUP, Duration.millis(2500));
            return;
        }
        if (selectedImageFile == null)
        {
            //utils.TrayNotificationAlert.notif("Reclamation", "Please select an image.",
              //      NotificationType.ERROR, AnimationType.POPUP, Duration.millis(2500));
            return;
        }
     //   uploadImage(selectedImageFile);
      //  reclamation.setImage(selectedImageFile.getName());
        reclamation.setDescription(commentInput.getText());
        reclamation.setNom(titleInput.getText());
        reclamation.setType(TypeInput.getValue());

      //  reclamation.setDate(java.sql.Date.valueOf(LocalDate.now()));
        reclamation.setEtat(0);
      /*  if (containsBadWords(reclamation.getDescription_reclamation())) {
            // Le commentaire contient des mots inappropriés, ne pas l'ajouter à la review
            // Afficher un message à l'utilisateur pour lui demander de modifier son
            // commentaire
            TrayNotificationAlert.notif("Bad Word Detected", "you should not use bad words.",
                    NotificationType.WARNING, AnimationType.POPUP, Duration.millis(2500));
            return;
        } else {
            review.setComment(comment);
        }*/

        ReclamationServices rc = new ReclamationServices();
    //    int id= rc.ajouterReturnsID(reclamation);

        Parent fxml;
        try {
            fxml = FXMLLoader.load(getClass().getResource("/RecItem/ReclamationsList.fxml"));
            content_area.getChildren().removeAll();
            content_area.getChildren().setAll(fxml);
        } catch (IOException e) {
            e.printStackTrace();
        }
       //     utils.TrayNotificationAlert.notif("Reclamation", "Reclamation added successfully.",
         //           NotificationType.SUCCESS, AnimationType.POPUP, Duration.millis(2500));
        this.commentInput.setText("");
        this.titleInput.setText("");
        this.TypeInput.getSelectionModel().select(0);
        this.selectedImageFile=null;
        this.img.setImage(null);
        this.updateBtn.setVisible(false);
        this.submitBtn.setVisible(true);
        addReviewsModel.setVisible(false);

    }
    public static Reclamation reclamation;
    private File selectedImageFile;
        @FXML
    public void uploadImage(MouseEvent actionEvent) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif")
        );
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        selectedImageFile = fileChooser.showOpenDialog(stage);
        if (selectedImageFile != null) {
            try {
                javafx.scene.image.Image image = new Image(new FileInputStream(selectedImageFile));
                img.setImage(image);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

    }

    public void goToNavigate(ActionEvent event) {
    }

    public void gotoAdmin(MouseEvent mouseEvent) {

            //RouterController.navigate("/AdminDashboard/AdminDashboard.fxml");
    }



    public void close_viewReplyModel(MouseEvent mouseEvent) {
        System.out.println("Closing modal");
        this.replyInput.setText("");
        this.viewReplyModel.setVisible(false);

    }

    public void close_viewReplyModal(MouseEvent mouseEvent) {
        System.out.println("Closing modal");

        this.replyInput.setText("");
            this.viewReplyModel.setVisible(false);
    }
}

