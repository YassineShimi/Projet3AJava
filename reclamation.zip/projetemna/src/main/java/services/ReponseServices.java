package services;

import models.Reponse;
import models.Reponse;
import utils.MyDataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReponseServices {

    private Connection connection = MyDataBase.getInstance().getConnection();

    public ReponseServices() {}

    public void ajouter(Reponse reponsee) throws SQLException {
        String req = "INSERT INTO reponse (description) VALUES (?)";
        try (PreparedStatement pst = connection.prepareStatement(req)) {
            pst.setString(1, reponsee.getDescription());

            pst.executeUpdate();
        }
    }

    public void modifier(Reponse reponsee) throws SQLException {
        String req = "UPDATE reponsee SET description = ?, rec_id = ? WHERE id = ?";
        try (PreparedStatement pst = connection.prepareStatement(req)) {
            pst.setString(1, reponsee.getDescription());
            pst.setInt(3, reponsee.getId());
            pst.executeUpdate();
        }
    }

    public void supprimer(int id) throws SQLException {
        String req = "DELETE FROM reponsee WHERE id=?";
        PreparedStatement preparedStatement = this.connection.prepareStatement(req);
        preparedStatement.setInt(1, id);
        preparedStatement.executeUpdate();
    }

    public List<Reponse> getAllReponsees() throws SQLException {
        String req = "SELECT * FROM reponse";
        List<Reponse> reponsees = new ArrayList<>();
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery(req)) {
            while (rs.next()) {
                Reponse reponsee = new Reponse();
                reponsee.setId(rs.getInt("id"));
                reponsee.setDescription(rs.getString("description"));

                reponsees.add(reponsee);
            }
        }
        return reponsees;
    }
    public Reponse getById(int id) throws SQLException {
        String query = "SELECT * FROM reponse WHERE id = ?";
        try {
            PreparedStatement pst = connection.prepareStatement(query);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                Reponse rec = new Reponse();
                rec.setId(rs.getInt("id"));
                rec.setDescription(rs.getString("description"));
                System.out.println("Printing description"+rs.getString("description"));
                return rec;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    public int ajouterReturnsID(Reponse reponse) {
        String req = "INSERT INTO reponse (description) VALUES (?)";
        int generatedId = -1;

        try (PreparedStatement pst = connection.prepareStatement(req,Statement.RETURN_GENERATED_KEYS)) {
            pst.setString(1, reponse.getDescription());

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected == 1) {
                ResultSet generatedKeys = pst.getGeneratedKeys();
                if (generatedKeys.next()) {
                    generatedId = generatedKeys.getInt(1);
                }
                System.out.println("Reponse ajoutée!");
            } else {
                System.out.println("Erreur lors de l'ajout de la réponse.");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return generatedId;

    }
}
