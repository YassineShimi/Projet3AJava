package models;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.util.Callback;

public class Reclamation {
    private int id;
    private String type;


    private String description;

    private String nom;
    private int reponse_id;
    private int etat;



    public Reponse getReponse() {
        return reponse;
    }
    public void setReponse(Reponse reponse) {
        this.reponse = reponse;
    }

    public Reponse reponse;

    public Reclamation(){}
    public Reclamation(String type,  String description, String nom) {
        this.type = type;

        this.description = description;

        this.nom = nom;

    }


    public String getType() {
        return type;
    }



    public String getDescription() {
        return description;
    }


    public String getNom() {
        return nom;
    }



    public void setType(String type) {
        this.type= type;
    }



    public void setDescription(String description) {
        this.description = description;
    }


    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getReponse_id() {
        return reponse_id;
    }

    public void setReponse_id(int reponse_id) {
        this.reponse_id = reponse_id;
    }

    public int getEtat() {
        return etat;
    }

    public void setEtat(int etat) {
        this.etat = etat;
    }

    @Override
    public String toString() {
        return "Reclamation{" +
                "id=" + id +
                ", type='" + type + '\'' +
                ", description='" + description + '\'' +
                ", nom='" + nom + '\'' +
                ", reponse_id=" + reponse_id +
                ", etat=" + etat +
                ", reponse=" + reponse +
                '}';
    }

    public ObservableValue<String> getResponseDescription() {
        if (reponse != null) {
            return new SimpleStringProperty(this.reponse.getDescription());
        } else {
            return new SimpleStringProperty("");
        }
    }


    public static TableColumn<Reclamation, String> createResponseColumn() {
        TableColumn<Reclamation, String> responseColumn = new TableColumn<>("Response Description");
        responseColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Reclamation, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Reclamation, String> param) {
                return param.getValue().getResponseDescription();
            }
        });
        return responseColumn;
    }
}
