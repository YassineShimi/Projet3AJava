package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import services.ReclamationServices;
import models.Reclamation;
import java.sql.SQLException;
import javafx.collections.ObservableList;


public class ModifierReclamation {

    @FXML
    private TextField descriptionField;

    @FXML
    private TextField nom;

    @FXML
    private ComboBox<String> typeComboBox;


    @FXML
    private Button modifierButton;

    private ReclamationServices reclamationServices;
    private Reclamation reclamation;
    public ModifierReclamation() {
        this.reclamationServices = new ReclamationServices(); // Initialisez reclamationServices dans le constructeur
    }


    public void initData(Reclamation reclamation) {
        this.reclamation = reclamation;
        // Afficher les données de la réclamation dans les champs de texte
        descriptionField.setText(reclamation.getDescription());
        nom.setText(String.valueOf(reclamation.getNom()));
    }

    @FXML
    void handleModifierReclamation(ActionEvent actionEvent) {
        // Récupérer les nouvelles valeurs saisies par l'utilisateur
        String nouvelleDescription = descriptionField.getText();
        String nouveauNom = nom.getText();






        reclamation.setDescription(nouvelleDescription);
        reclamation.setNom(nouveauNom);


        // Mettre à jour la réclamation dans la base de données en utilisant ReclamationServices
        try {
            reclamationServices.modifier(reclamation);
            showAlert(Alert.AlertType.INFORMATION, "Succès", "Réclamation modifiée", "La réclamation a été modifiée avec succès.");
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Erreur lors de la modification de la réclamation", e.getMessage());
        }
    }


    private void showAlert(Alert.AlertType alertType, String title, String headerText, String contentText) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(contentText);
        alert.showAndWait();
    }
}
