package controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import models.Reclamation;
import models.Reponse;
import services.ReclamationServices;
import services.ReponseServices;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

public class AjouterReponsee implements Initializable {
    @FXML

    ReponseServices rs = new ReponseServices();
    Reponse r = new Reponse();
    @FXML
    protected  TableView<Reponse> tableview;
    @FXML
    private TextField dp;

    public void AjouterReponsee(ActionEvent actionEvent) {
        try {
            Reponse r=new Reponse( dp.getText());

            rs.ajouter(r);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setContentText("Une réponse a été ajouté avec succées");
            Optional<ButtonType> buttonType = alert.showAndWait();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/listReponse.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (SQLException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erroe");
            alert.setContentText(e.getMessage());
            Optional<ButtonType> buttonType = alert.showAndWait();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        List<Reclamation> reclamations = null;
        try {
            ReclamationServices rs=new ReclamationServices();
            reclamations = rs.afficher();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        ObservableList<Reclamation> reclamationList = FXCollections.observableArrayList(reclamations);


    }

    private Reclamation reclamation; // Réclamation à laquelle on répond

    private ListReclamation listReclamationController; // Référence au contrôleur ListReclamation

    public void initData(Reclamation reclamation, ListReclamation listReclamationController) {
        this.reclamation = reclamation;
        this.listReclamationController = listReclamationController;
        // Utilisez la réclamation pour initialiser les champs de la fenêtre de réponse
        // Par exemple, setTextField(reclamation.getDescription());
    }

    public void validerReponse() {
        // Mettre à jour l'état et la réponse de la réclamation

        reclamation.setEtat("Répondu");
        reclamation.setReponse_id(r.getId());

        // Mettre à jour la TableView dans ListReclamation pour refléter les changements
        listReclamationController.updateTableView();


    }

    public class TableCellDeleteButton extends TableCell<Reponse, Reponse> {
        private final Button deleteButton;

        TableCellDeleteButton() {
            this.deleteButton = new Button("Supprimer");
            this.deleteButton.setOnAction(event -> {
                Reponse reponsee = getTableView().getItems().get(getIndex());
                try {
                    rs.supprimer(reponsee.getId());
                } catch (SQLException e) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Erreur");
                    alert.setContentText(e.getMessage());
                    alert.showAndWait();
                }
            });
        }

        @Override
        protected void updateItem(Reponse item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
                setGraphic(null);
            } else {
                setGraphic(deleteButton);
            }
        }
    }

    private class TableCellEditButton extends TableCell<Reponse, Reponse> {
        private final Button editButton;

        TableCellEditButton() {
            this.editButton = new Button("Modifier");
            this.editButton.setOnAction(event -> {
                Reponse reponsee = getTableView().getItems().get(getIndex());
                // Code pour gérer l'événement de modification
            });
        }

        @Override
        protected void updateItem(Reponse item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
                setGraphic(null);
            } else {
                setGraphic(editButton);
            }
        }
    }
}
