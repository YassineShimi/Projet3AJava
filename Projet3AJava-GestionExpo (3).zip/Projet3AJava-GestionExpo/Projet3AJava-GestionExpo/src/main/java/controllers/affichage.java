package controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import models.Reclamation;
import services.ReclamationServices;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

public class affichage implements Initializable {
    @FXML
    private GridPane reclamcontainer;

    private List<Reclamation> reclamations;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialize your list of reclamations using the ReclamationServices
        ReclamationServices reclamationServices = new ReclamationServices();
        try {
            reclamations = reclamationServices.afficher();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        // Display the reclamations
        for (Reclamation reclam :reclamations) {
            displayReclamations();
        }
    }

    private void displayReclamations() {
        int colomun=0;
        int row=1;
        // Clear previous content in reclamcontainer
        reclamcontainer.getChildren().clear();

        // Loop through reclamations and create Carte instances for each
        for (Reclamation reclamation : reclamations) {
            try {
                // Load the Carte FXML file
                FXMLLoader loader = new FXMLLoader(getClass().getResource("../carte.fxml"));
                GridPane carte = loader.load();

                // Get the controller instance from the loader
                Carte carteController = loader.getController();

                // Set the data for the Carte instance
                carteController.setData(reclamation);
if(colomun==6){
    colomun=0;
    ++row;
}
                // Add the Carte instance to reclamcontainer
                reclamcontainer.getChildren().add(carte);
                colomun++;
                GridPane.setMargin(carte,new Insets(10));

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
