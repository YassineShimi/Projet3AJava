package models;

import javafx.collections.ObservableList;

public class Reclamation {
    private int id;
    private String type;


    private String description;

    private String nom;
    private int reponse_id;
    private String etat;




    public Reclamation(){}
    public Reclamation(String type,  String description, String nom) {
        this.type = type;

        this.description = description;

        this.nom = nom;

    }


    public String getType() {
        return type;
    }



    public String getDescription() {
        return description;
    }


    public String getNom() {
        return nom;
    }



    public void setType(String id) {
        this.type= type;
    }



    public void setDescription(String description) {
        this.description = description;
    }


    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return
                "type=" + type+
                ", description='" + description+
                        ", nom='" + nom;
    }

    public int getReponse_id() {
        return reponse_id;
    }

    public void setReponse_id(int reponse_id) {
        this.reponse_id = reponse_id;
    }

    public String getEtat() {
        return etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }
}
