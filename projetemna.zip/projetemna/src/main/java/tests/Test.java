package tests;

import utils.MyDataBase;

public class Test {
    public static void main(String[] args) {
        MyDataBase bd = MyDataBase.getInstance();

    }
}
