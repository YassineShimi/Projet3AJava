package services;
import models.Reclamation;
import utils.MyDataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReclamationServices implements IService<Reclamation> {
    private Connection connection = MyDataBase.getInstance().getConnection();

    public ReclamationServices() {}

    @Override
    public int ajouter(Reclamation reclamation) throws SQLException {
        String req = "INSERT INTO reclamation (reponse_id, type, description, nom, etat) VALUES (null, ?, ?, ?, 0)";
        PreparedStatement pst = connection.prepareStatement(req, Statement.RETURN_GENERATED_KEYS);
        pst.setString(1, reclamation.getType());
        pst.setString(2, reclamation.getDescription());
        pst.setString(3, reclamation.getNom());
        pst.executeUpdate();

        ResultSet rs = pst.getGeneratedKeys();
        if (rs.next()) {
            return rs.getInt(1); // Renvoie l'ID généré de la réclamation
        } else {
            throw new SQLException("L'ajout de la réclamation a échoué, aucun ID généré obtenu.");
        }
    }





    @Override
    public void modifier(Reclamation reclamation) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Connexion à la base de données
            connection = MyDataBase.getConnection();

            String query = "UPDATE reclamation SET description = ?, nom = ? , type = ? WHERE id = ?";
            preparedStatement = connection.prepareStatement(query);

            // Remplacement des paramètres dans la requête SQL par les nouvelles valeurs de l'avis
            preparedStatement.setString(1, reclamation.getDescription());


            preparedStatement.setString(2, reclamation.getNom());
            preparedStatement.setString(3, reclamation.getType());
            preparedStatement.setInt(4,reclamation.getId());

            // Exécution de la requête
            preparedStatement.executeUpdate();
        } finally {
            // Fermeture des ressources
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        }
    }

    @Override
    public void supprimer(int id) throws SQLException {
        String req = "DELETE FROM `reclamation` WHERE id=?";
        PreparedStatement preparedStatement = this.connection.prepareStatement(req);
        preparedStatement.setInt(1, id);
        preparedStatement.executeUpdate();

    }
    public void supprimer(Reclamation reclamation) throws SQLException {
        // Connexion à la base de données choubikloubiki
        Connection conn = MyDataBase.getConnection(); // Remplacez Database.getConnectionChoubikloubiki() par la méthode appropriée pour obtenir une connexion à votre base de données choubikloubiki
        PreparedStatement stmt = null;

        try {
            // Requête SQL pour supprimer l'avis
            String sql = "DELETE FROM reclamation WHERE id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, reclamation.getId()); // Remplacez getId() par la méthode appropriée pour obtenir l'ID de l'avis

            // Exécuter la requête
            stmt.executeUpdate();
        } finally {
            // Fermeture des ressources
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }
    @Override
    public List<Reclamation> afficher() throws SQLException { String req = "SELECT * FROM reclamation";
        List<Reclamation> reclamations = new ArrayList<>();
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery(req)) {
            while (rs.next()) {
                Reclamation r = new Reclamation();
                System.out.println(rs.getString("type"));
                r.setType(rs.getString("type"));
                r.setDescription(rs.getString("description"));
                ReponseServices reponseservice=new ReponseServices();
                r.setReponse_id(rs.getInt("reponse_id"));
                r.setReponse(reponseservice.getById(r.getReponse_id()));
                System.out.println(reponseservice.getById(r.getReponse_id()));
                r.setNom(rs.getString("nom"));
                        r.setId(rs.getInt("id"));
                        System.out.println(reclamations);
                        r.setEtat(rs.getInt("etat"));
                reclamations.add(r);
            }
        }
        return reclamations;
    }

    public Reclamation getReclamationById(int id) throws SQLException {
        Reclamation reclamation = null;
        String query = "SELECT * FROM reclamation WHERE id = ?";
        try (PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setInt(1, id);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    String description = rs.getString("description");
                    String type = rs.getString("type");
                    String nom = rs.getString("nom");
                    reclamation = new Reclamation(type, description,nom);
                }
            }
        }
        return reclamation;
    }


    public void modifierReponse(Reclamation reclamation) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Connexion à la base de données
            connection = MyDataBase.getConnection();

            String query = "UPDATE reclamation SET reponse_id = ?, etat = ? WHERE id = ?";
            preparedStatement = connection.prepareStatement(query);

            // Remplacement des paramètres dans la requête SQL par les nouvelles valeurs de l'avis
            preparedStatement.setInt(1, reclamation.getReponse_id());


            preparedStatement.setInt(2, reclamation.getEtat());
            preparedStatement.setInt(3,reclamation.getId());
            // Exécution de la requête
            preparedStatement.executeUpdate();
        } finally {
            // Fermeture des ressources
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        }

    }
}


