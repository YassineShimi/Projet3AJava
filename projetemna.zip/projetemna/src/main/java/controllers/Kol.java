package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import javafx.stage.Stage;

import java.io.IOException;
import javafx.scene.control.Button;
public class Kol {
    @FXML
    private Button buttonavis;

    @FXML
    private Button buttonreclamation;






    @FXML
    void handlereclamation(ActionEvent event) {
        try {
            Parent page2 = FXMLLoader.load(getClass().getResource("/accueil2.fxml"));
            Scene scene2 = new Scene(page2);
            Stage app_stage = (Stage) buttonreclamation.getScene().getWindow();
            app_stage.setScene(scene2);
            app_stage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
    @FXML
    void initialize() {

        buttonreclamation.setOnAction(this::handlereclamation);



    }

}
