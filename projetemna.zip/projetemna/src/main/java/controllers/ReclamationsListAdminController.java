package controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import models.Reclamation;
import services.ReclamationServices;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

public class ReclamationsListAdminController implements Initializable {

    @FXML
    GridPane reclamationsListContainer;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ReclamationServices rs=new ReclamationServices();
        List<Reclamation> reclamationList;
        try {
            reclamationList = rs.afficher();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        int column = 0;
        int row = 1;
        try {
            for (int i = 0; i < reclamationList.size(); i++) {

                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("/Reclamations/ReclamationItem.fxml"));
                AnchorPane oneReclamationCard = fxmlLoader.load();
                ReclamationItemController reclamationItemController = fxmlLoader.getController();
                reclamationItemController.setReclamationsData(reclamationList.get(i));

                if (column == 3) {
                    column = 0;
                    ++row;
                }
                reclamationsListContainer.add(oneReclamationCard, column++, row);
                GridPane.setMargin(oneReclamationCard, new Insets(0, 20, 20, 10));

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
